const express = require("express");
const app = express();
const cors = require("cors");
const port = 3000;
require("dotenv").config();

const urlRoutes = require("./routes/urlRoutes");
const authRoutes = require("./routes/authRoutes");
const subscriptionRoutes = require("./routes/subscriptionRoutes");

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.send("backend server is running");
});

app.use("/turain", authRoutes);
app.use("/turain", urlRoutes);

app.use("/turain/subscription", subscriptionRoutes);

app.listen(port, () => {
  console.log(`server is running on port ${port}`);
});
