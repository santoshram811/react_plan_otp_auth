import React from 'react'

const Services = () => {
  return (
    <div>
     <h1>services</h1> 
    </div>
  )
}

export default Services
