// import { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import axiosInstance from "../api/axios";
// import { FaEdit } from "react-icons/fa";
// import UserUrlHistory from "./userUrlHistory/UserUrlHistory";

// const UrlShortener = () => {
//   const [originalUrl, setOriginalUrl] = useState("");
//   const [shortUrl, setShortUrl] = useState("");
//   const [message, setMessage] = useState("");
//   const [copied, setCopied] = useState(false);

//   const [durationValue, setDurationValue] = useState(5);
//   const [durationType, setDurationType] = useState("minutes");

//   const [profile, setProfile] = useState(null);
//   const [name, setName] = useState("");
//   const [email, setEmail] = useState("");
//   const [isNameEditable, setIsNameEditable] = useState(false);
//   const [isEmailEditable, setIsEmailEditable] = useState(false);
//   const [urlHistory, setUrlHistory] = useState([]);

//   const navigate = useNavigate();

//   const handleLogout = () => {
//     localStorage.removeItem("token");
//     navigate("/login");
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     if (!originalUrl) {
//       setMessage("Please enter a URL");
//       return;
//     }

//     try {
//       const response = await axiosInstance.post("/shorten", {
//         originalUrl,
//         durationValue,
//         durationType,
//       });

//       setShortUrl(response.data.shortUrl);
//       setCopied(false);
//       const newHistoryItem = {
//         original_url: originalUrl,
//         short_code: response.data.shortUrl.split("/").pop(),
//         created_at: new Date().toISOString(),
//         expires_at: new Date(Date.now() + durationValue * 60000).toISOString(),
//         status: "active",
//       };

//       setUrlHistory((prev) => [newHistoryItem, ...prev]);

//       setProfile((prev) => {
//         if (!prev) return prev;

//         const used = Number(prev.used_urls || 0);

//         let remaining;
//         if (prev.remaining_urls === "unlimited") {
//           remaining = "unlimited";
//         } else if (typeof prev.remaining_urls === "number") {
//           remaining = Math.max(prev.remaining_urls - 1, 0);
//         } else {
//           remaining = 0;
//         }

//         return {
//           ...prev,
//           used_urls: used + 1,
//           remaining_urls: remaining,
//         };
//       });

//       setMessage(response.data.exists ? "URL already exists" : "New short URL created");
//     } catch (error) {
//       if (error.response) {
//         if (error.response.status === 401) {
//           setMessage("Session expired. Please login again.");
//           handleLogout();
//         } else if (error.response.status === 403) {
//           setMessage(error.response.data.message);
//         } else {
//           setMessage("Something went wrong");
//         }
//       } else {
//         setMessage("Network error");
//       }
//     }
//   };

//   const handleCopy = async () => {
//     await navigator.clipboard.writeText(shortUrl);
//     setCopied(true);
//     setTimeout(() => setCopied(false), 2000);
//   };

//   const refreshProfile = async () => {
//     try {
//       const res = await axiosInstance.get("/profile");
//       setProfile(res.data);
//     } catch (err) {
//       handleLogout();
//     }
//   };

//   const handleActivatePlan = async () => {
//     try {
//       await axiosInstance.post("/subscription/activate-plan");
//       setMessage("Plan activated successfully");

//       const res = await axiosInstance.get("/profile");
//       setProfile(res.data);
//     } catch (err) {
//       setMessage("Failed to activate plan");
//     }
//   };

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const [profileRes, historyRes] = await Promise.all([
//           axiosInstance.get("/profile"),
//           axiosInstance.get("/history"),
//         ]);

//         setProfile(profileRes.data);
//         setName(profileRes.data.name || "");
//         setEmail(profileRes.data.email || "");
//         setUrlHistory(historyRes.data);
//       } catch (err) {
//         if (err.response?.status === 401) {
//           handleLogout();
//         }
//       }
//     };

//     fetchData();
//   }, []);

//   const handleSaveProfile = async () => {
//     try {
//       await axiosInstance.put("/profile", { name, email });
//       setIsEmailEditable(false);
//       setIsNameEditable(false);
//       alert("Profile updated successfully");
//     } catch (err) {
//       alert("Failed to update your details");
//     }
//   };

//   const reactivateUrl = async (shortcodeId) => {
//     try {
//       await axiosInstance.post(`/reactivate/${shortcodeId}`);

//       // refresh history after reactivation
//       const res = await axiosInstance.get("/history");
//       setUrlHistory(res.data);

//       // refresh profile counters
//       const profileRes = await axiosInstance.get("/profile");
//       setProfile(profileRes.data);
//     } catch (err) {
//       alert(" you have crossed the url limits");
//     }
//   };

//   return (
//     <div>
//       <div>
//         <h1>users ursl created history</h1>
//         <UserUrlHistory history={urlHistory} reactivateUrl={reactivateUrl} />
//       </div>
//       <div>
//         <h1>upcoming plans</h1>
//         {profile?.upcomingPlan && (
//           <div className="mt-3 p-3 border rounded bg-yellow-50">
//             <p>
//               <strong>Upcoming Plan:</strong>{" "}
//               <span className="font-semibold">{profile.upcomingPlan.name}</span>
//             </p>

//             <button
//               onClick={handleActivatePlan}
//               className="mt-2 bg-blue-600 text-white px-4 py-1 rounded"
//             >
//               Activate Now
//             </button>
//           </div>
//         )}
//       </div>
//       <h1>user profile section</h1>
//       <div style={{ padding: "40px" }}>
//         <div>
//           {/* PROFILE SECTION */}
//           {profile && (
//             <div
//               style={{
//                 border: "1px solid #ddd",
//                 padding: "15px",
//                 marginBottom: "20px",
//                 borderRadius: "6px",
//               }}
//             >
//               <h3>User Profile</h3>

//               <div>
//                 {/* PLAN INFO */}
//                 <div
//                   style={{
//                     marginTop: "10px",
//                     padding: "10px",
//                     background: "#f4f4f4",
//                     borderRadius: "6px",
//                   }}
//                 >
//                   <p>
//                     <strong>Current Plan:</strong>{" "}
//                     <span className="text-green-700 font-semibold">
//                       {profile.plan_name || "not active any plan"}
//                     </span>
//                   </p>

//                   {profile?.limits && (
//                     <div>
//                       <p>
//                         <strong>Max URLs:</strong> {profile.limits.max_urls}
//                       </p>

//                       <p>
//                         <strong>Used URLs:</strong> {profile.used_urls}
//                       </p>

//                       <p>
//                         <strong>Remaining URLs:</strong>{" "}
//                         <span className="text-red-600 font-bold">{profile.remaining_urls}</span>
//                       </p>

//                       {/* <p>
//                         <strong>Reactivated URLs:</strong>{" "}
//                         <span className="text-blue-600 font-bold">
//                           {profile.reactivated_urls || 0}
//                         </span>
//                       </p> */}

//                       <p>
//                         <strong>Total Clicks Used:</strong> {profile.total_clicks_used}
//                       </p>
//                       <p>
//                         <strong>Allowed Clicks:</strong> {profile.allowed_clicks}
//                       </p>
//                       <p>
//                         <strong>Remaining Clicks:</strong>{" "}
//                         <span className="text-red-600">{profile.remaining_clicks}</span>
//                       </p>
//                     </div>
//                   )}
//                 </div>
//               </div>
//               <p>
//                 <strong>Mobile:</strong> {profile.mobile_number}
//               </p>
//               <div className="flex justify-center">
//                 <input
//                   disabled={!isNameEditable}
//                   type="text"
//                   placeholder="Enter name"
//                   value={name}
//                   onChange={(e) => setName(e.target.value)}
//                   style={{ display: "block", marginBottom: "10px", padding: "6px" }}
//                   className={`bg-gray-400 px-2 py-1 rounded ${
//                     !isNameEditable ? "opacity-60 cursor-not-allowed" : ""
//                   }`}
//                 />
//                 <FaEdit
//                   className="cursor-pointer text-xl text-blue-600"
//                   title="Edit name"
//                   onClick={() => setIsNameEditable(true)}
//                 />
//               </div>
//               <div className="flex justify-center">
//                 <input
//                   disabled={!isEmailEditable}
//                   type="email"
//                   placeholder="Enter email"
//                   value={email}
//                   onChange={(e) => setEmail(e.target.value)}
//                   style={{ display: "block", marginBottom: "10px", padding: "6px" }}
//                   className={`bg-gray-400 px-2 py-1 rounded ${
//                     !isEmailEditable ? "opacity-60 cursor-not-allowed" : ""
//                   }`}
//                 />
//                 <FaEdit
//                   className="cursor-pointer text-xl text-blue-600"
//                   title="Edit email"
//                   onClick={() => setIsEmailEditable(true)}
//                 />
//               </div>
//               <button
//                 onClick={handleSaveProfile}
//                 className="bg-transparent hover:bg-green-500 text-green-700 font-semibold hover:text-white py-2 px-4 border border-green-500 hover:border-transparent rounded"
//               >
//                 Save Profile
//               </button>
//             </div>
//           )}
//         </div>

//         {/* HEADER */}
//         <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
//           <h2>Dashboard</h2>
//           <button
//             onClick={handleLogout}
//             className="bg-transparent hover:bg-red-500 text-red-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
//           >
//             Logout
//           </button>
//         </div>

//         {/* FORM */}
//         <form onSubmit={handleSubmit} style={{ marginTop: "20px" }}>
//           <input
//             className="bg-gray-400"
//             type="text"
//             placeholder="Enter original URL"
//             value={originalUrl}
//             onChange={(e) => setOriginalUrl(e.target.value)}
//             style={{ width: "320px", padding: "8px" }}
//           />

//           <br />
//           <br />

//           <input
//             type="number"
//             min="1"
//             max={99}
//             value={durationValue}
//             onChange={(e) => {
//               const v = e.target.value;
//               if (v.length <= 2) setDurationValue(v);
//             }}
//           />

//           <select value={durationType} onChange={(e) => setDurationType(e.target.value)}>
//             <option value="minutes">Minutes</option>
//             <option value="hours">Hours</option>
//             <option value="days">Days</option>
//           </select>

//           <button
//             className="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
//             type="submit"
//           >
//             Shorten
//           </button>
//         </form>

//         {message && <p>{message}</p>}

//         {shortUrl && (
//           <div>
//             <p>
//               Short URL:{" "}
//               <a
//                 className="text underline text-blue-800"
//                 href={shortUrl}
//                 target="_blank"
//                 rel="noreferrer"
//               >
//                 {shortUrl}
//               </a>
//             </p>

//             <button onClick={handleCopy}>{copied ? "Copied!" : "Copy"}</button>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default UrlShortener;

// import { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import axiosInstance from "../api/axios";
// import { FaEdit } from "react-icons/fa";
// import UserUrlHistory from "./userUrlHistory/UserUrlHistory";

// const UrlShortener = () => {
//   const [originalUrl, setOriginalUrl] = useState("");
//   const [shortUrl, setShortUrl] = useState("");
//   const [message, setMessage] = useState("");
//   const [copied, setCopied] = useState(false);

//   const [durationValue, setDurationValue] = useState(5);
//   const [durationType, setDurationType] = useState("minutes");

//   const [profile, setProfile] = useState(null);
//   const [name, setName] = useState("");
//   const [email, setEmail] = useState("");
//   const [isNameEditable, setIsNameEditable] = useState(false);
//   const [isEmailEditable, setIsEmailEditable] = useState(false);
//   const [urlHistory, setUrlHistory] = useState([]);

//   const [showHistory, setShowHistory] = useState(false);
//   const [showAnalytics, setShowAnalytics] = useState(false);

//   const navigate = useNavigate();

//   const handleLogout = () => {
//     localStorage.removeItem("token");
//     navigate("/login");
//   };

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const [profileRes, historyRes] = await Promise.all([
//           axiosInstance.get("/profile"),
//           axiosInstance.get("/history"),
//         ]);

//         setProfile(profileRes.data);
//         setName(profileRes.data.name || "");
//         setEmail(profileRes.data.email || "");
//         setUrlHistory(historyRes.data);
//       } catch (err) {
//         if (err.response?.status === 401) handleLogout();
//       }
//     };

//     fetchData();
//   }, []);

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     if (!originalUrl) {
//       setMessage("Please enter a URL");
//       return;
//     }

//     try {
//       const response = await axiosInstance.post("/shorten", {
//         originalUrl,
//         durationValue,
//         durationType,
//       });

//       setShortUrl(response.data.shortUrl);
//       setCopied(false);

//       const historyRes = await axiosInstance.get("/history");
//       setUrlHistory(historyRes.data);

//       const profileRes = await axiosInstance.get("/profile");
//       setProfile(profileRes.data);

//       setMessage(response.data.exists ? "URL already exists" : "New short URL created");
//     } catch (error) {
//       if (error.response?.status === 401) handleLogout();
//       else setMessage(error.response?.data?.message || "Something went wrong");
//     }
//   };

//   const handleCopy = async () => {
//     await navigator.clipboard.writeText(shortUrl);
//     setCopied(true);
//     setTimeout(() => setCopied(false), 2000);
//   };

//   const handleSaveProfile = async () => {
//     try {
//       await axiosInstance.put("/profile", { name, email });
//       setIsEmailEditable(false);
//       setIsNameEditable(false);
//       alert("Profile updated successfully");
//     } catch {
//       alert("Failed to update your details");
//     }
//   };

//   const reactivateUrl = async (shortcodeId) => {
//     try {
//       await axiosInstance.post(`/reactivate/${shortcodeId}`);

//       const historyRes = await axiosInstance.get("/history");
//       setUrlHistory(historyRes.data);

//       const profileRes = await axiosInstance.get("/profile");
//       setProfile(profileRes.data);
//     } catch {
//       alert("You reached your plan limit");
//     }
//   };

//   return (
//     <div className="min-h-screen bg-gray-100 p-6">
//       {/* PROFILE CARD */}
//       {profile && (
//         <div className="max-w-3xl mx-auto bg-white shadow-xl rounded-xl p-6 mb-6">
//           <div className="flex justify-between items-center mb-4">
//             <h3 className="text-xl font-bold">User Dashboard</h3>

//             <span className="bg-green-600 text-white px-3 py-1 rounded-full text-sm">
//               Active Plan: {profile.plan_name}
//             </span>
//           </div>

//           <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
//             <p>
//               <strong>Mobile:</strong> {profile.mobile_number}
//             </p>
//             <p>
//               <strong>Max url:</strong> {profile.limits.max_urls}
//             </p>
//             <p>
//               <strong>Used URLs:</strong> {profile.used_urls}
//             </p>
//             <p>
//               <strong>Used URLs:</strong> {profile.used_urls}
//             </p>
//             <p>
//               <strong>Remaining URLs:</strong> {profile.remaining_urls}
//             </p>
//             <p>
//               <strong>Total Clicks:</strong> {profile.total_clicks_used}
//             </p>
//             <p>
//               <strong>Remaining Clicks:</strong> {profile.remaining_clicks}
//             </p>
//           </div>

//           {/* PROFILE EDIT */}
//           <div className="flex gap-2 mb-2">
//             <input
//               disabled={!isNameEditable}
//               value={name}
//               onChange={(e) => setName(e.target.value)}
//               className="border px-2 py-1 rounded w-full"
//               placeholder="Name"
//             />
//             <FaEdit
//               onClick={() => setIsNameEditable(true)}
//               className="cursor-pointer text-blue-600"
//             />
//           </div>

//           <div className="flex gap-2 mb-4">
//             <input
//               disabled={!isEmailEditable}
//               value={email}
//               onChange={(e) => setEmail(e.target.value)}
//               className="border px-2 py-1 rounded w-full"
//               placeholder="Email"
//             />
//             <FaEdit
//               onClick={() => setIsEmailEditable(true)}
//               className="cursor-pointer text-blue-600"
//             />
//           </div>

//           <button
//             onClick={handleSaveProfile}
//             className="bg-green-600 text-white px-4 py-2 rounded mb-4"
//           >
//             Save Profile
//           </button>

//           {/* ACTION BUTTONS */}
//           <div className="flex gap-4">
//             <button
//               onClick={() => {
//                 setShowHistory(!showHistory);
//                 setShowAnalytics(false);
//               }}
//               className="bg-blue-600 text-white px-4 py-2 rounded"
//             >
//               {showHistory ? "Hide History" : "View URL History"}
//             </button>

//             <button
//               onClick={() => {
//                 setShowAnalytics(!showAnalytics);
//                 setShowHistory(false);
//               }}
//               className="bg-purple-600 text-white px-4 py-2 rounded"
//             >
//               {showAnalytics ? "Hide Analytics" : "URL Analytics"}
//             </button>

//             <button onClick={handleLogout} className="bg-green-600 text-white px-4 py-2 rounded">
//               Logout
//             </button>
//           </div>
//         </div>
//       )}

//       {/* HISTORY PANEL */}
//       {showHistory && (
//         <div className="max-w-5xl mx-auto bg-white shadow rounded p-4 mb-6">
//           <UserUrlHistory history={urlHistory} reactivateUrl={reactivateUrl} />
//         </div>
//       )}

//       {/* ANALYTICS PANEL */}
//       {showAnalytics && profile && (
//         <div className="max-w-3xl mx-auto bg-white shadow rounded p-6 mb-6">
//           <h3 className="text-lg font-bold mb-2">Analytics</h3>
//           <p>maximul allow on plan: {profile.limits.max_urls}</p>
//           <p>Total URLs created: {profile.generated_short_urls}</p>
//           <p>Total clicks: {profile.total_clicks_used}</p>
//           <p>Remaining clicks: {profile.remaining_clicks}</p>
//         </div>
//       )}

//       {/* SHORTEN FORM */}
//       <div className="max-w-xl mx-auto bg-white shadow rounded p-6">
//         <form onSubmit={handleSubmit}>
//           <input
//             type="text"
//             placeholder="Enter URL"
//             value={originalUrl}
//             onChange={(e) => setOriginalUrl(e.target.value)}
//             className="border w-full p-2 rounded mb-4"
//           />

//           <div className="flex gap-2 mb-4">
//             <input
//               type="number"
//               value={durationValue}
//               onChange={(e) => setDurationValue(e.target.value)}
//               className="border p-2 rounded w-20"
//             />

//             <select
//               value={durationType}
//               onChange={(e) => setDurationType(e.target.value)}
//               className="border p-2 rounded"
//             >
//               <option value="minutes">Minutes</option>
//               <option value="hours">Hours</option>
//               <option value="days">Days</option>
//             </select>
//           </div>

//           <button className="bg-green-600 text-white px-4 py-2 rounded">Shorten URL</button>
//         </form>

//         {message && <p className="mt-2">{message}</p>}

//         {shortUrl && (
//           <div className="mt-4">
//             <a href={shortUrl} target="_blank" rel="noreferrer" className="text-blue-600 underline">
//               {shortUrl}
//             </a>

//             <button onClick={handleCopy} className="ml-4 bg-gray-200 px-2 py-1 rounded">
//               {copied ? "Copied!" : "Copy"}
//             </button>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default UrlShortener;


import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../api/axios";
import { FaEdit } from "react-icons/fa";
import UserUrlHistory from "./userUrlHistory/UserUrlHistory";

const UrlShortener = () => {
  const [originalUrl, setOriginalUrl] = useState("");
  const [shortUrl, setShortUrl] = useState("");
  const [message, setMessage] = useState("");
  const [copied, setCopied] = useState(false);

  const [durationValue, setDurationValue] = useState(5);
  const [durationType, setDurationType] = useState("");

  const [profile, setProfile] = useState(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [isNameEditable, setIsNameEditable] = useState(false);
  const [isEmailEditable, setIsEmailEditable] = useState(false);
  const [urlHistory, setUrlHistory] = useState([]);

  const [showHistory, setShowHistory] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);

  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [profileRes, historyRes] = await Promise.all([
          axiosInstance.get("/profile"),
          axiosInstance.get("/history"),
        ]);

        setProfile(profileRes.data);
        setName(profileRes.data.name || "");
        setEmail(profileRes.data.email || "");
        setUrlHistory(historyRes.data);
      } catch (err) {
        if (err.response?.status === 401) handleLogout();
      }
    };

    fetchData();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!originalUrl) {
      setMessage("Please enter a URL");
      return;
    }

    try {
      const response = await axiosInstance.post("/shorten", {
        originalUrl,
        durationValue,
        durationType,
      });

      setShortUrl(response.data.shortUrl);
      setCopied(false);

      const historyRes = await axiosInstance.get("/history");
      setUrlHistory(historyRes.data);

      const profileRes = await axiosInstance.get("/profile");
      setProfile(profileRes.data);

      setMessage(response.data.exists ? "URL already exists" : "New short URL created");
    } catch (error) {
      if (error.response?.status === 401) handleLogout();
      else setMessage(error.response?.data?.message || "Something went wrong");
    }
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(shortUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveProfile = async () => {
    try {
      await axiosInstance.put("/profile", { name, email });
      setIsEmailEditable(false);
      setIsNameEditable(false);
      alert("Profile updated successfully");
    } catch {
      alert("Failed to update your details");
    }
  };

  const reactivateUrl = async (shortcodeId) => {
    try {
      await axiosInstance.post(`/reactivate/${shortcodeId}`);

      const historyRes = await axiosInstance.get("/history");
      setUrlHistory(historyRes.data);

      const profileRes = await axiosInstance.get("/profile");
      setProfile(profileRes.data);
    } catch {
      alert("You reached your plan limit");
    }
  };

  return (
    <div className="min-h-screen bg-gray-200 p-6">
     {/* PROFILE DASHBOARD */}
{profile && (
  <div className="max-w-6xl mx-auto mt-8 space-y-6">
    {/* Top Profile Card */}
    <div className="bg-white rounded-2xl shadow-md p-6">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">User Dashboard</h2>
          <p className="text-gray-500 text-sm">
            Mobile: {profile.mobile_number}
          </p>
        </div>

        <div className="flex flex-col items-start md:items-end">
          <span className="bg-green-100 text-green-700 px-4 py-1 rounded-full text-sm font-semibold">
            Active Plan: {profile.plan_name}
          </span>

          {profile.plan_expiry && (
            <p className="text-sm text-red-500 mt-1 font-medium">
              Expires on{" "}
              {new Date(profile.plan_expiry).toLocaleDateString()}
            </p>
          )}
        </div>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
        <div className="bg-gray-50 p-4 rounded-xl text-center">
          <p className="text-gray-500 text-sm">Max URLs</p>
          <p className="text-xl font-bold">{profile.limits.max_urls}</p>
        </div>

        <div className="bg-gray-50 p-4 rounded-xl text-center">
          <p className="text-gray-500 text-sm">Used URLs</p>
          <p className="text-xl font-bold">{profile.used_urls}</p>
        </div>

        <div className="bg-gray-50 p-4 rounded-xl text-center">
          <p className="text-gray-500 text-sm">Remaining URLs</p>
          <p className="text-xl font-bold">{profile.remaining_urls}</p>
        </div>

        <div className="bg-gray-50 p-4 rounded-xl text-center">
          <p className="text-gray-500 text-sm">Total Clicks</p>
          <p className="text-xl font-bold">
            {profile.total_clicks_used}
          </p>
        </div>
      </div>
    </div>

    {/* Editable Profile Card */}
    <div className="bg-white rounded-2xl shadow-md p-6">
      <h3 className="text-lg font-semibold mb-4">Edit Profile</h3>

      <div className="flex gap-3 mb-3">
        <input
          disabled={!isNameEditable}
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="border px-3 py-2 rounded w-full focus:ring focus:ring-blue-200"
          placeholder="Name"
        />
        <FaEdit
          onClick={() => setIsNameEditable(true)}
          className="cursor-pointer text-blue-600 mt-2"
        />
      </div>

      <div className="flex gap-3 mb-4">
        <input
          disabled={!isEmailEditable}
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="border px-3 py-2 rounded w-full focus:ring focus:ring-blue-200"
          placeholder="Email"
        />
        <FaEdit
          onClick={() => setIsEmailEditable(true)}
          className="cursor-pointer text-blue-600 mt-2"
        />
      </div>

      <button
        onClick={handleSaveProfile}
        className="bg-green-600 hover:bg-green-700 text-white px-5 py-2 rounded-lg"
      >
        Save Profile
      </button>
    </div>

    {/* Action Buttons */}
    <div className="flex flex-wrap gap-4">
      <button
        onClick={() => {
          setShowHistory(!showHistory);
          setShowAnalytics(false);
        }}
        className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg"
      >
        {showHistory ? "Hide History" : "View URL History"}
      </button>

      <button
        onClick={() => {
          setShowAnalytics(!showAnalytics);
          setShowHistory(false);
        }}
        className="bg-purple-600 hover:bg-purple-700 text-white px-5 py-2 rounded-lg"
      >
        {showAnalytics ? "Hide Analytics" : "URL Analytics"}
      </button>

      <button
        onClick={handleLogout}
        className="bg-red-600 hover:bg-red-700 text-white px-5 py-2 rounded-lg"
      >
        Logout
      </button>
    </div>
  </div>
)}

{/* HISTORY SECTION */}
{showHistory && (
  <div className="max-w-6xl mx-auto mt-6 bg-white rounded-2xl shadow-md p-6">
    <UserUrlHistory
      history={urlHistory}
      reactivateUrl={reactivateUrl}
    />
  </div>
)}

{/* ANALYTICS SECTION */}
{showAnalytics && profile && (
  <div className="max-w-6xl mx-auto mt-6 bg-white rounded-2xl shadow-md p-6">
    <h3 className="text-xl font-semibold mb-4">Analytics Overview</h3>

    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      <div className="bg-gray-50 p-4 rounded-xl text-center">
        <p className="text-gray-500 text-sm">Plan Max URLs</p>
        <p className="text-xl font-bold">
          {profile.limits.max_urls}
        </p>
      </div>

      <div className="bg-gray-50 p-4 rounded-xl text-center">
        <p className="text-gray-500 text-sm">Total URLs</p>
        <p className="text-xl font-bold">
          {profile.generated_short_urls}
        </p>
      </div>

      <div className="bg-gray-50 p-4 rounded-xl text-center">
        <p className="text-gray-500 text-sm">Total Clicks</p>
        <p className="text-xl font-bold">
          {profile.total_clicks_used}
        </p>
      </div>

      <div className="bg-gray-50 p-4 rounded-xl text-center">
        <p className="text-gray-500 text-sm">Remaining Clicks</p>
        <p className="text-xl font-bold">
          {profile.remaining_clicks}
        </p>
      </div>
    </div>
  </div>
)}


      {/* SHORTEN FORM */}
      <div className="max-w-xl mx-auto bg-white shadow rounded p-6">
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Enter URL"
            value={originalUrl}
            onChange={(e) => setOriginalUrl(e.target.value)}
            className="border w-full p-2 rounded mb-4"
          />

          {/* <div className="flex gap-2 mb-4">
            <input
              type="number"
              value={durationValue}
              onChange={(e) => setDurationValue(e.target.value)}
              className="border p-2 rounded w-20"
            />

            <select
              value={durationType}
              onChange={(e) => setDurationType(e.target.value)}
              className="border p-2 rounded"
            >
              <option value="minutes">Minutes</option>
              <option value="hours">Hours</option>
              <option value="days">Days</option>
            </select>
          </div> */}

          <button className="bg-green-600 text-white px-4 py-2 rounded">Shorten URL</button>
        </form>

        {message && <p className="mt-2">{message}</p>}

        {shortUrl && (
          <div className="mt-4">
            <a href={shortUrl} target="_blank" rel="noreferrer" className="text-blue-600 underline">
              {shortUrl}
            </a>

            <button onClick={handleCopy} className="ml-4 bg-gray-200 px-2 py-1 rounded">
              {copied ? "Copied!" : "Copy"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default UrlShortener;
